/* Fichier: hello.c
* affiche 'Hello World !' à l'écran.
* auteur: Paul-Malo Poisson
*/

#include <stdio.h>

int main() {
    printf("Hello World !");
    return 0;
}