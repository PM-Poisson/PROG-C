#ifndef FICHIER_H
#define FICHIER_H

void lire_fichier(const char *nom_de_fichier);
void ecrire_dans_fichier(const char *nom_de_fichier, const char *message);

#endif
