#ifndef OPERATOR_H
#define OPERATOR_H

int somme(int a, int b);
int difference(int a, int b);
int produit(int a, int b);
int quotient(int a, int b);
int modulo(int a, int b);
int et_logique(int a, int b);
int ou_logique(int a, int b);
int negation(int a); // pour l'opérateur '~'

#endif
