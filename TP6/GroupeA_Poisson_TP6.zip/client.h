/* client.h
 * Prototype du client.
 */

#ifndef CLIENT_H
#define CLIENT_H

int run_client(const char *bmp_path);

#endif
