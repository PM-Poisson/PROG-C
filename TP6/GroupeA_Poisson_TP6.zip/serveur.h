/* serveur.h
 * Prototype du serveur.
 */

#ifndef SERVEUR_H
#define SERVEUR_H

int run_server(void);

#endif
