#ifndef CLIENT_H
#define CLIENT_H

#define MAX_MSG 1000

void envoie_message();
void envoie_operateur_numeros(char operateur, int a, int b);

#endif
