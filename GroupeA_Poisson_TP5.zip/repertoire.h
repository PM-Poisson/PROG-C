#ifndef REPERTOIRE_H
#define REPERTOIRE_H

void lire_dossier(const char *nom_repertoire);
void lire_dossier_recursif(const char *nom_repertoire);
void lire_dossier_iteratif(const char *nom_repertoire);

#endif
